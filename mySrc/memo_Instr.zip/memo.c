#include <stdio.h>
#include <string.h>
#include <sys/fcntl.h>
#include <dirent.h>
#include <stdlib.h>

void openDir(char (*names)[256]){

	DIR *dp;
	int i=0;

	struct dirent *dent;
	if( (dp = opendir("./memo"))==NULL){
		puts("dir open error");
		exit(-1);
	}

	while((dent = readdir(dp))!=NULL){
		strcpy(names[i],dent->d_name);
		if(!strcmp(names[i],".")||!strcmp(names[i],"..")){
			continue;
		}
		i++;
	}
	strcpy(names[i],"");
	closedir(dp);

}
void printDir(char (*names)[256]){

	int i=0;
	while(1){
		if(!strcmp(names[i],"")){
			break;
		}
		printf("%d.%s\n",i,names[i]);
		i++;
	}
}

void myRead(char (*names)[256]){
	
	int fd;
	int idx;
	char buf[256];
	printDir(names);
	printf("읽을 파일의 번호 :");
	scanf("%d",&idx);
	sprintf(buf,"%s%s","memo/",names[idx]);
	fd = open(buf,O_RDONLY);
	
	if(fd<0){
		puts("file open error");
		exit(1);
	}
	memset(buf,'\0',256);
	while(read(fd,buf,256)>0){
		printf("%s",buf);
		memset(buf,'\0',256);
	}

	close(fd);
	
	
	/*
	int i=0, fd;
	char ch;
	
	while(1){
	
	if((fd = open(names[i],O_RDONLY))<0){
		perror("open()");
		exit(-1);
	}

		read(fd,&ch,255);	
		

		i++;
	
	}
	*/
}

void main(){
	
	char files[256][256];
	int menu,flag =1;

	if(access("memo",F_OK)!=0){
		mkdir("memo",0777);	
	}	
	
	openDir(files);
	printDir(files);

	while(flag){
		puts("1.read 2.write 3.delete 4.stop");
		scanf("%d",&menu);
		switch(menu){
			case 1:
				{	
					myRead(files);
					break;
			   }
			case 2:
				{ //write();
					break;
				}
			case 3:
				{	//delete();
					break;
				}
			case 4:
				{flag = 0;
					break;
				}
					
		}
	}


}
